import './App.css';
import index from './index';
import Main from './pages/Main'
function App() {
  return (
    
    <Main></Main>

  );
}

export default App;


  

