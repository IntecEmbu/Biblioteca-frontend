import React from 'react'
import Navbar from '../components/Navbar/index'
import Form from '../components/Form/index'
import '../pages/main.css'


function Main() {
  return (
    <>
    
    <Navbar></Navbar>
    <h2 id='h1'>
        Cadastro do livro
      </h2>
    <Form></Form>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    </>
  )
}
export default Main;